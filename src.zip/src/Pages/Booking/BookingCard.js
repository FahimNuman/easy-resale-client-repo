import React from 'react';

const BookingCard = () => {
    return (
        <div>
            
        </div>
    );
};

export default BookingCard;