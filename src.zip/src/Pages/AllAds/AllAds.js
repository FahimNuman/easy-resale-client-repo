import React from 'react';

const AllAds = () => {
    return (
        <div className='nx-5'> 
            all ads
        </div>
    );
};

export default AllAds;