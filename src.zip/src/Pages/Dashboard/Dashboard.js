import React from 'react';

const Dashboard = () => {
    return (
        <div>
            comming soon.....
        </div>
    );
};

export default Dashboard;